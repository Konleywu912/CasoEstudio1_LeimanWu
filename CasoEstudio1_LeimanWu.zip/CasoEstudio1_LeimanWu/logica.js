let estudiantes = [
    { nombre: "Maria", apellidos: "Mora Perez", nota: 90 },
    { nombre: "Pedro", apellidos: "Sibaja Lopez", nota: 60 },
    { nombre: "Marco", apellidos: "Rojas Castro", nota: 78 }
];

const tabla = document.getElementById("tablaEstudiantes");
const resumen = document.getElementById("resumen");
const form = document.getElementById("formEstudiante");
const error = document.getElementById("error");

form.addEventListener("submit", function(e) {
    e.preventDefault();

    let nombre = document.getElementById("nombre").value.trim();
    let apellidos = document.getElementById("apellidos").value.trim();
    let nota = document.getElementById("nota").value.trim();

    if (!nombre || !apellidos || !nota) {
        error.textContent = "Todos los campos son obligatorios";
        return;
    }

    nota = Number(nota);

    if (isNaN(nota) || nota < 0 || nota > 100) {
        error.textContent = "Nota inválida";
        return;
    }

    estudiantes.push({ nombre, apellidos, nota });

    form.reset();
    error.textContent = "";

    renderTabla();
});

function renderTabla() {

    tabla.innerHTML = "";

    let suma = 0;
    let mayor = estudiantes[0];
    let menor = estudiantes[0];

    estudiantes.forEach(e => {

        let clase = "";

        if (e.nota >= 80) clase = "nota-alta";
        if (e.nota < 65) clase = "nota-baja";

        tabla.innerHTML += `
            <tr>
                <td>${e.nombre}</td>
                <td>${e.apellidos}</td>
                <td class="${clase}">${e.nota}</td>
            </tr>
        `;

        suma += e.nota;

        if (e.nota > mayor.nota) mayor = e;
        if (e.nota < menor.nota) menor = e;
    });

    let promedio = (suma / estudiantes.length).toFixed(2);

    resumen.innerHTML = `
        <h3>Resumen</h3>
        <p>Mayor: ${mayor.nombre} ${mayor.apellidos} (${mayor.nota})</p>
        <p>Menor: ${menor.nombre} ${menor.apellidos} (${menor.nota})</p>
        <p>Promedio: ${promedio}</p>
    `;
}

renderTabla();